package game;

import java.util.Random;

public class randomGenV2 {
	public static void main(String[] args) {
		Random cardValue = new Random();
		int cardRand = cardValue.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 11   , 12   , 13
		
		Random suitValue = new Random();
		int suitRand = suitValue.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardVal = "";
		String suit = "";
		
		
		if (cardRand == 1) {
			cardVal = "Ace"; // 1
		} else if (cardRand == 2) {
			cardVal = "Two"; // 2
		} else if (cardRand == 3) {
			cardVal = "Three"; // 3
		} else if (cardRand == 4) {
			cardVal = "Four"; // 4
		} else if (cardRand == 5) {
			cardVal = "Five"; // 5
		} else if (cardRand == 6) {
			cardVal = "Six"; // 6
		} else if (cardRand == 7) {
			cardVal = "Seven"; // 7
		} else if (cardRand == 8) {
			cardVal = "Eight"; // 8
		} else if (cardRand == 9) {
			cardVal = "Nine"; // 9
		} else if (cardRand == 10) {
			cardVal = "Ten"; // 10
		} else if (cardRand == 11) {
			cardVal = "Jack"; // 11
		} else if (cardRand == 12) {
			cardVal = "Queen"; // 12
		} else {
			cardVal = "King"; // 13
		}
		
		
		if (suitRand == 1) {
			suit = "Clubs"; // 1
		} else if (suitRand == 2) {
			suit = "Diamonds"; // 2
		} else if (suitRand == 3) {
			suit = "Hearts"; // 3
		} else {
			suit = "Spades"; // 4
		}
	
		
		System.out.println(cardVal);
		System.out.println(suit);
		
	}
}
