package game;

import java.util.Random;
import java.util.Scanner;

public class start {
	public static void main(String[] args) throws InterruptedException {
		Scanner userInput = new Scanner(System.in);
		System.out.println("Type P or Play to Begin Blackjack\n" + "Or type R or Rules to read the rules of Blackjack");
		
		String userInputString = userInput.nextLine();

boolean boolContinue = false;

	if (userInputString.equalsIgnoreCase("p") || userInputString.equalsIgnoreCase("play")) {
		System.out.println("The game is now starting");
		Thread.sleep(1000);
		boolContinue = true;
	} else if (userInputString.equalsIgnoreCase("r") || userInputString.equalsIgnoreCase("rules")) {
		System.out.println("These are the game rules: you have 30 seconds to read");
		System.out.println("Blackjack is a game that uses a standard 52-card pack. \n"
				+ "Face cards are worth up to 10.\n"
				+ "An Ace is worth 11 unless the amount would cause a �bust�, an ace is worth 1 at that point. \n"
				+ "The other cards are worth their shown value: 2, 3, 4 etc�\n"
				+ "The goal is to try to draw cards in an attempt to beat the dealer by getting 21 or as close to 21, without going over. \n"
				+ "Going over 21 is known as �busting� or �bust�.\n"
				+ "At the start, a player is dealt 2 cards face-up while the dealer has 1 card face up and one face down.\n"
				+ "Once the cards have been dealt, the player can choose either to hit or stand.\n"
				+ "If the player chooses to stand, the dealer will turn-over their face down card. \n"
				+ "If the dealer�s cards are lower than the player, they will draw until they either beat the player or �bust�.\n"
				+ "If the player chooses to �hit� instead of �stand�, the dealer will deal them another card.\n"
				+ "The player can continue to hit in an attempt to reach the desired amount or �bust�.\n"
				+ "If a player is dealt a 10 or face card and an Ace it is known as Blackjack. \n"
				+ "for our modifications, the dealer and player can only hold a max of 4 cards each in their hands" );
		Thread.sleep(30000);
		boolContinue = true;
	} else {
		System.out.println("invalid, restart game");
		System.exit(0);
	}


	
if (boolContinue = true) {
	 
	{	Random cardValue1 = new Random(); // random dealer card #1
		int cardRand1 = cardValue1.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 11   , 12   , 13
		
		Random suitValue1 = new Random();
		int suitRand1 = suitValue1.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer1 = "";
		String suitDealer1 = "";
		
		
		if (cardRand1 == 1) {
			cardValDealer1 = "Ace"; // 1
		} else if (cardRand1 == 2) {
			cardValDealer1 = "Two"; // 2
		} else if (cardRand1 == 3) {
			cardValDealer1 = "Three"; // 3
		} else if (cardRand1 == 4) {
			cardValDealer1 = "Four"; // 4
		} else if (cardRand1 == 5) {
			cardValDealer1 = "Five"; // 5
		} else if (cardRand1 == 6) {
			cardValDealer1 = "Six"; // 6
		} else if (cardRand1 == 7) {
			cardValDealer1 = "Seven"; // 7
		} else if (cardRand1 == 8) {
			cardValDealer1 = "Eight"; // 8
		} else if (cardRand1 == 9) {
			cardValDealer1 = "Nine"; // 9
		} else if (cardRand1 == 10) {
			cardValDealer1 = "Ten"; // 10
		} else if (cardRand1 == 11) {
			cardValDealer1 = "Jack"; // 11
		} else if (cardRand1 == 12) {
			cardValDealer1 = "Queen"; // 12
		} else {
			cardValDealer1 = "King";  // 13 
		}
		
		
		if (suitRand1 == 1) {
			suitDealer1 = "Clubs"; // 1
		} else if (suitRand1 == 2) {
			suitDealer1 = "Diamonds"; // 2
		} else if (suitRand1 == 3) {
			suitDealer1 = "Hearts"; // 3
		} else {
			suitDealer1 = "Spades"; // 4
		}	

		
	{ 	Random cardValue2 = new Random(); // random dealer card #2
		int cardRand2 = cardValue2.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 11   , 12   , 13
		
		Random suitValue2 = new Random();
		int suitRand2 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer2 = "";
		String suitDealer2 = "";
		
		
		if (cardRand2 == 1) {
			cardValDealer2 = "Ace"; // 1
		} else if (cardRand2 == 2) {
			cardValDealer2 = "Two"; // 2
		} else if (cardRand2 == 3) {
			cardValDealer2 = "Three"; // 3
		} else if (cardRand2 == 4) {
			cardValDealer2 = "Four"; // 4
		} else if (cardRand2 == 5) {
			cardValDealer2 = "Five"; // 5
		} else if (cardRand2 == 6) {
			cardValDealer2 = "Six"; // 6
		} else if (cardRand2 == 7) {
			cardValDealer2 = "Seven"; // 7
		} else if (cardRand2 == 8) {
			cardValDealer2 = "Eight"; // 8
		} else if (cardRand2 == 9) {
			cardValDealer2 = "Nine"; // 9
		} else if (cardRand2 == 10) {
			cardValDealer2 = "Ten"; // 10
		} else if (cardRand2 == 11) {
			cardValDealer2 = "Jack"; // 11
		} else if (cardRand2 == 12) {
			cardValDealer2 = "Queen"; // 12
		} else {
			cardValDealer2 = "King";  // 13 
		}
		
		
		if (suitRand2 == 1) {
			suitDealer2 = "Clubs"; // 1
		} else if (suitRand2 == 2) {
			suitDealer2 = "Diamonds"; // 2
		} else if (suitRand2 == 3) {
			suitDealer2 = "Hearts"; // 3
		} else {
			suitDealer2 = "Spades"; // 4
		}
		
	{ 	Random cardValue3 = new Random(); // random dealer card #3
		int cardRand3 = cardValue3.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 11   , 12   , 13
		
		Random suitValue3 = new Random();
		int suitRand3 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer3 = "";
		String suitDealer3 = "";
		
		
		if (cardRand3 == 1) {
			cardValDealer3 = "Ace"; // 1
		} else if (cardRand3 == 2) {
			cardValDealer3 = "Two"; // 2
		} else if (cardRand3 == 3) {
			cardValDealer3 = "Three"; // 3
		} else if (cardRand3 == 4) {
			cardValDealer3 = "Four"; // 4
		} else if (cardRand3 == 5) {
			cardValDealer3 = "Five"; // 5
		} else if (cardRand3 == 6) {
			cardValDealer3 = "Six"; // 6
		} else if (cardRand3 == 7) {
			cardValDealer3 = "Seven"; // 7
		} else if (cardRand3 == 8) {
			cardValDealer3 = "Eight"; // 8
		} else if (cardRand3 == 9) {
			cardValDealer3 = "Nine"; // 9
		} else if (cardRand3 == 10) {
			cardValDealer3 = "Ten"; // 10
		} else if (cardRand3 == 11) {
			cardValDealer3 = "Jack"; // 11
		} else if (cardRand3 == 12) {
			cardValDealer3 = "Queen"; // 12
		} else {
			cardValDealer3 = "King";  // 13 
		}
		
		
		if (suitRand3 == 1) {
			suitDealer3 = "Clubs"; // 1
		} else if (suitRand3 == 2) {
			suitDealer3 = "Diamonds"; // 2
		} else if (suitRand3 == 3) {
			suitDealer3 = "Hearts"; // 3
		} else {
			suitDealer3 = "Spades"; // 4
		}
		
	{ 	Random cardValue4 = new Random(); // random dealer card #4
		int cardRand4 = cardValue4.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 11   , 12   , 13
		
		Random suitValue4 = new Random();
		int suitRand4 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer4 = "";
		String suitDealer4 = "";
		
		
		if (cardRand4 == 1) {
			cardValDealer4 = "Ace"; // 1
		} else if (cardRand4 == 2) {
			cardValDealer4 = "Two"; // 2
		} else if (cardRand4 == 3) {
			cardValDealer4 = "Three"; // 3
		} else if (cardRand4 == 4) {
			cardValDealer4 = "Four"; // 4
		} else if (cardRand4 == 5) {
			cardValDealer4 = "Five"; // 5
		} else if (cardRand4 == 6) {
			cardValDealer4 = "Six"; // 6
		} else if (cardRand4 == 7) {
			cardValDealer4 = "Seven"; // 7
		} else if (cardRand4 == 8) {
			cardValDealer4 = "Eight"; // 8
		} else if (cardRand4 == 9) {
			cardValDealer4 = "Nine"; // 9
		} else if (cardRand4 == 10) {
			cardValDealer4 = "Ten"; // 10
		} else if (cardRand4 == 11) {
			cardValDealer4 = "Jack"; // 11
		} else if (cardRand4 == 12) {
			cardValDealer4 = "Queen"; // 12
		} else {
			cardValDealer4 = "King";  // 13 
		}
		
		
		if (suitRand3 == 1) {
			suitDealer4 = "Clubs"; // 1
		} else if (suitRand4 == 2) {
			suitDealer4 = "Diamonds"; // 2
		} else if (suitRand4 == 3) {
			suitDealer4 = "Hearts"; // 3
		} else {
			suitDealer4 = "Spades"; // 4
		}
		
		
		System.out.println(cardRand1 + " " + cardRand2);
		
		int twoCardTotal = cardRand1 + cardRand2;
		int threeCardTotal = cardRand1 + cardRand2 + cardRand3;
		int fourCardTotal = cardRand1 + cardRand2 + cardRand3 + cardRand4;
		
		
		System.out.println(twoCardTotal);
		System.out.println(threeCardTotal);
		System.out.println(fourCardTotal);

	
//		if (twoCardTotal < 17) {
//			underSeventeen = true;
//		} else {
//			dealerFinal = (cardRand1 + cardRand2);
//			System.out.println(dealerFinal);
//		}
//		
//	
//		if (underSeventeen = true);
//			
//		
//		
//		
		
	}
	}
		
	}

	
		
	
//		System.out.println("The Dealer has a face up card of: " + cardValDealer1 + " " + suitDealer1);
//		
//		
//		
//		System.out.println("Your two cards are:");
//	
		}


}
		}
}



	
