package game;

import java.util.Random;
import java.util.Scanner;

public class start {
	public static void main(String[] args) throws InterruptedException {
		Scanner userInput = new Scanner(System.in);
		System.out.println("Type P or Play to Begin Blackjack\n" + "Or type R or Rules to read the rules of Blackjack");
		
		String userInputString = userInput.nextLine();

boolean boolContinue = false;

	if (userInputString.equalsIgnoreCase("p") || userInputString.equalsIgnoreCase("play")) {
		System.out.println("The game is now starting");
		Thread.sleep(1000);
		boolContinue = true;
	} else if (userInputString.equalsIgnoreCase("r") || userInputString.equalsIgnoreCase("rules")) {
		System.out.println("These are the game rules: you have 30 seconds to read");
		System.out.println("Blackjack is a game that uses a standard 52-card pack. \n"
				+ "Face cards are worth up to 10.\n"
				+ "An Ace is worth 11 unless the amount would cause a �bust�, an ace is worth 1 at that point. \n"
				+ "The other cards are worth their shown value: 2, 3, 4 etc�\n"
				+ "The goal is to try to draw cards in an attempt to beat the dealer by getting 21 or as close to 21, without going over. \n"
				+ "Going over 21 is known as �busting� or �bust�.\n"
				+ "At the start, a player is dealt 2 cards face-up while the dealer has 1 card face up and one face down.\n"
				+ "Once the cards have been dealt, the player can choose either to hit or stand.\n"
				+ "If the player chooses to stand, the dealer will turn-over their face down card. \n"
				+ "If the dealer�s cards are lower than the player, they will draw until they either beat the player or �bust�.\n"
				+ "If the player chooses to �hit� instead of �stand�, the dealer will deal them another card.\n"
				+ "The player can continue to hit in an attempt to reach the desired amount or �bust�.\n"
				+ "If a player is dealt a 10 or face card and an Ace it is known as Blackjack. \n"
				+ "for our modifications, the dealer and player can only hold a max of 4 cards each in their hands" 
				+ "modification #2 - All aces = 1 (to get 21 you will need a combination of 3 or 4 cards)" );
		Thread.sleep(30000);
		boolContinue = true;
	} else {
		System.out.println("invalid, restart game");
		System.exit(0);
	}


	
if (boolContinue = true) {
	 
	{	Random cardValue1 = new Random(); // random dealer card #1
		int cardRand1 = cardValue1.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		
		Random suitValue1 = new Random();
		int suitRand1 = suitValue1.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer1 = "";
		String suitDealer1 = "";
		
		
		if (cardRand1 == 1) {
			cardValDealer1 = "Ace"; // 11
		} else if (cardRand1 == 2) {
			cardValDealer1 = "Two"; // 2
		} else if (cardRand1 == 3) {
			cardValDealer1 = "Three"; // 3
		} else if (cardRand1 == 4) {
			cardValDealer1 = "Four"; // 4
		} else if (cardRand1 == 5) {
			cardValDealer1 = "Five"; // 5
		} else if (cardRand1 == 6) {
			cardValDealer1 = "Six"; // 6
		} else if (cardRand1 == 7) {
			cardValDealer1 = "Seven"; // 7
		} else if (cardRand1 == 8) {
			cardValDealer1 = "Eight"; // 8
		} else if (cardRand1 == 9) {
			cardValDealer1 = "Nine"; // 9
		} else if (cardRand1 == 10) {
			cardValDealer1 = "Ten"; // 10
		} else if (cardRand1 == 11) {
			cardRand1 = 10;
			cardValDealer1 = "Jack"; // 10
		} else if (cardRand1 == 12) {
			cardValDealer1 = "Queen"; // 10
			cardRand1 = 10;
		} else {
			cardValDealer1 = "King";  // 10 
			cardRand1 = 10;
		}
		
		
		if (suitRand1 == 1) {
			suitDealer1 = "Clubs"; // 1
		} else if (suitRand1 == 2) {
			suitDealer1 = "Diamonds"; // 2
		} else if (suitRand1 == 3) {
			suitDealer1 = "Hearts"; // 3
		} else {
			suitDealer1 = "Spades"; // 4
		}	

		
	{ 	Random cardValue2 = new Random(); // random dealer card #2
		int cardRand2 = cardValue2.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		
		Random suitValue2 = new Random();
		int suitRand2 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer2 = "";
		String suitDealer2 = "";
		
		
		if (cardRand2 == 1) {
			cardValDealer2 = "Ace"; // 11
		} else if (cardRand2 == 2) {
			cardValDealer2 = "Two"; // 2
		} else if (cardRand2 == 3) {
			cardValDealer2 = "Three"; // 3
		} else if (cardRand2 == 4) {
			cardValDealer2 = "Four"; // 4
		} else if (cardRand2 == 5) {
			cardValDealer2 = "Five"; // 5
		} else if (cardRand2 == 6) {
			cardValDealer2 = "Six"; // 6
		} else if (cardRand2 == 7) {
			cardValDealer2 = "Seven"; // 7
		} else if (cardRand2 == 8) {
			cardValDealer2 = "Eight"; // 8
		} else if (cardRand2 == 9) {
			cardValDealer2 = "Nine"; // 9
		} else if (cardRand2 == 10) {
			cardValDealer2 = "Ten"; // 10
		} else if (cardRand2 == 11) {
			cardValDealer2 = "Jack"; // 10
			cardRand2 = 10;
		} else if (cardRand2 == 12) {
			cardValDealer2 = "Queen"; // 10
			cardRand2 = 10;
		} else {
			cardValDealer2 = "King";  // 10
			cardRand2 = 10;
		}
		
		
		if (suitRand2 == 1) {
			suitDealer2 = "Clubs"; // 1
		} else if (suitRand2 == 2) {
			suitDealer2 = "Diamonds"; // 2
		} else if (suitRand2 == 3) {
			suitDealer2 = "Hearts"; // 3
		} else {
			suitDealer2 = "Spades"; // 4
		}
		
	{ 	Random cardValue3 = new Random(); // random dealer card #3
		int cardRand3 = cardValue3.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		
		Random suitValue3 = new Random();
		int suitRand3 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer3 = "";
		String suitDealer3 = "";
		
		
		if (cardRand3 == 1) {
			cardValDealer3 = "Ace"; // 11
		} else if (cardRand3 == 2) {
			cardValDealer3 = "Two"; // 2
		} else if (cardRand3 == 3) {
			cardValDealer3 = "Three"; // 3
		} else if (cardRand3 == 4) {
			cardValDealer3 = "Four"; // 4
		} else if (cardRand3 == 5) {
			cardValDealer3 = "Five"; // 5
		} else if (cardRand3 == 6) {
			cardValDealer3 = "Six"; // 6
		} else if (cardRand3 == 7) {
			cardValDealer3 = "Seven"; // 7
		} else if (cardRand3 == 8) {
			cardValDealer3 = "Eight"; // 8
		} else if (cardRand3 == 9) {
			cardValDealer3 = "Nine"; // 9
		} else if (cardRand3 == 10) {
			cardValDealer3 = "Ten"; // 10
		} else if (cardRand3 == 11) {
			cardValDealer3 = "Jack"; // 10
			cardRand3 = 10;
		} else if (cardRand3 == 12) {
			cardValDealer3 = "Queen"; // 10
			cardRand3 = 10;
		} else {
			cardValDealer3 = "King";  // 10
			cardRand3 = 10;
		}
		
		
		if (suitRand3 == 1) {
			suitDealer3 = "Clubs"; // 1
		} else if (suitRand3 == 2) {
			suitDealer3 = "Diamonds"; // 2
		} else if (suitRand3 == 3) {
			suitDealer3 = "Hearts"; // 3
		} else {
			suitDealer3 = "Spades"; // 4
		}
		
	{ 	Random cardValue4 = new Random(); // random dealer card #4
		int cardRand4 = cardValue4.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		
		Random suitValue4 = new Random();
		int suitRand4 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		
		String cardValDealer4 = "";
		String suitDealer4 = "";
		
		
		if (cardRand4 == 1) {
			cardValDealer4 = "Ace"; // 11
		} else if (cardRand4 == 2) {
			cardValDealer4 = "Two"; // 2
		} else if (cardRand4 == 3) {
			cardValDealer4 = "Three"; // 3
		} else if (cardRand4 == 4) {
			cardValDealer4 = "Four"; // 4
		} else if (cardRand4 == 5) {
			cardValDealer4 = "Five"; // 5
		} else if (cardRand4 == 6) {
			cardValDealer4 = "Six"; // 6
		} else if (cardRand4 == 7) {
			cardValDealer4 = "Seven"; // 7
		} else if (cardRand4 == 8) {
			cardValDealer4 = "Eight"; // 8
		} else if (cardRand4 == 9) {
			cardValDealer4 = "Nine"; // 9
		} else if (cardRand4 == 10) {
			cardValDealer4 = "Ten"; // 10
		} else if (cardRand4 == 11) {
			cardValDealer4 = "Jack"; // 10
			cardRand4 = 10;
		} else if (cardRand4 == 12) {
			cardValDealer4 = "Queen"; // 10
			cardRand4 = 10;
		} else {
			cardValDealer4 = "King";  // 10
			cardRand4 = 10;
		}
		
		
		if (suitRand3 == 1) {
			suitDealer4 = "Clubs"; // 1
		} else if (suitRand4 == 2) {
			suitDealer4 = "Diamonds"; // 2
		} else if (suitRand4 == 3) {
			suitDealer4 = "Hearts"; // 3
		} else {
			suitDealer4 = "Spades"; // 4
		}
		
	{	Random cardValue5 = new Random(); // random user card #1
        int cardRand5 = cardValue5.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10

        Random suitValue5 = new Random();
        int suitRand5 = suitValue5.nextInt(1, 5);
        //Clubs, Diamonds, Hearts, Spades (suits and associated vals)
        //1    , 2       , 3     , 4

        String cardValPlayer1 = "";
        String suitPlayer1 = "";


        if (cardRand5 == 1) {
            cardValPlayer1 = "Ace"; // 1
        } else if (cardRand5 == 2) {
            cardValPlayer1 = "Two"; // 2
        } else if (cardRand5 == 3) {
            cardValPlayer1 = "Three"; // 3
        } else if (cardRand5 == 4) {
            cardValPlayer1 = "Four"; // 4
        } else if (cardRand5 == 5) {
            cardValPlayer1 = "Five"; // 5
        } else if (cardRand5 == 6) {
            cardValPlayer1 = "Six"; // 6
        } else if (cardRand5 == 7) {
            cardValPlayer1 = "Seven"; // 7
        } else if (cardRand5 == 8) {
            cardValPlayer1 = "Eight"; // 8
        } else if (cardRand5 == 9) {
            cardValPlayer1 = "Nine"; // 9
        } else if (cardRand5 == 10) {
            cardValPlayer1 = "Ten"; // 10
        } else if (cardRand5 == 11) {
            cardValPlayer1 = "Jack"; // 10
			cardRand5 = 10;
        } else if (cardRand5 == 12) {
            cardValPlayer1 = "Queen"; // 10
			cardRand5 = 10;
        } else {
            cardValPlayer1 = "King";  // 10
			cardRand5 = 10;
        }


        if (suitRand5 == 1) {
            suitPlayer1 = "Clubs"; // 1
        } else if (suitRand5 == 2) {
            suitPlayer1 = "Diamonds"; // 2
        } else if (suitRand5 == 3) {
            suitPlayer1 = "Hearts"; // 3
        } else {
            suitPlayer1 = "Spades"; // 4
        }
        
        
   {    Random cardValue6 = new Random(); // random user card #2
        int cardRand6 = cardValue6.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
        Random suitValue6 = new Random();
        int suitRand6 = suitValue6.nextInt(1, 5);
        //Clubs, Diamonds, Hearts, Spades (suits and associated vals)
        //1    , 2       , 3     , 4

        String cardValPlayer2 = "";
        String suitPlayer2 = "";


        if (cardRand6 == 1) {
            cardValPlayer2 = "Ace"; // 1
        } else if (cardRand6 == 2) {
            cardValPlayer2 = "Two"; // 2
        } else if (cardRand6 == 3) {
            cardValPlayer2 = "Three"; // 3
        } else if (cardRand6 == 4) {
            cardValPlayer2 = "Four"; // 4
        } else if (cardRand6 == 5) {
            cardValPlayer2 = "Five"; // 5
        } else if (cardRand6 == 6) {
            cardValPlayer2 = "Six"; // 6
        } else if (cardRand6 == 7) {
            cardValPlayer2 = "Seven"; // 7
        } else if (cardRand6 == 8) {
            cardValPlayer2 = "Eight"; // 8
        } else if (cardRand6 == 9) {
            cardValPlayer2 = "Nine"; // 9
        } else if (cardRand6 == 10) {
            cardValPlayer2 = "Ten"; // 10
        } else if (cardRand6 == 11) {
            cardValPlayer2 = "Jack"; // 10
			cardRand6 = 10;
        } else if (cardRand6 == 12) {
            cardValPlayer2 = "Queen"; // 10
			cardRand6 = 10;
        } else {
            cardValPlayer2 = "King";  // 10
			cardRand6 = 10;
        }


        if (suitRand6 == 1) {
            suitPlayer2 = "Clubs"; // 1
        } else if (suitRand6 == 2) {
            suitPlayer2 = "Diamonds"; // 2
        } else if (suitRand6 == 3) {
            suitPlayer2 = "Hearts"; // 3
        } else {
            suitPlayer2 = "Spades"; // 4
        }

   {    Random cardValue7 = new Random(); // random user card #3
        int cardRand7 = cardValue7.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10

        Random suitValue7 = new Random();
        int suitRand7 = suitValue7.nextInt(1, 5);
        //Clubs, Diamonds, Hearts, Spades (suits and associated vals)
        //1    , 2       , 3     , 4

        String cardValPlayer3 = "";
        String suitPlayer3 = "";


        if (cardRand7 == 1) {
            cardValPlayer3 = "Ace"; // 1
        } else if (cardRand7 == 2) {
            cardValPlayer3 = "Two"; // 2
        } else if (cardRand7 == 3) {
            cardValPlayer3 = "Three"; // 3
        } else if (cardRand7 == 4) {
            cardValPlayer3 = "Four"; // 4
        } else if (cardRand7 == 5) {
            cardValPlayer3 = "Five"; // 5
        } else if (cardRand7 == 6) {
            cardValPlayer3 = "Six"; // 6
        } else if (cardRand7 == 7) {
            cardValPlayer3 = "Seven"; // 7
        } else if (cardRand7 == 8) {
            cardValPlayer3 = "Eight"; // 8
        } else if (cardRand7 == 9) {
            cardValPlayer3 = "Nine"; // 9
        } else if (cardRand7 == 10) {
            cardValPlayer3 = "Ten"; // 10
        } else if (cardRand7 == 11) {
            cardValPlayer3 = "Jack"; // 10
			cardRand7 = 10;
        } else if (cardRand7 == 12) {
            cardValPlayer3 = "Queen"; // 10
			cardRand7 = 10;
        } else {
            cardValPlayer3 = "King";  // 10 
			cardRand7 = 10;
        }


        if (suitRand7 == 1) {
            suitPlayer3 = "Clubs"; // 1
        } else if (suitRand7 == 2) {
            suitPlayer3 = "Diamonds"; // 2
        } else if (suitRand7 == 3) {
            suitPlayer3 = "Hearts"; // 3
        } else {
            suitPlayer3 = "Spades"; // 4
        }
        
   {    Random cardValue8 = new Random(); // random user card #4
        int cardRand8 = cardValue8.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10

        Random suitValue8 = new Random();
        int suitRand8 = suitValue8.nextInt(1, 5);
        //Clubs, Diamonds, Hearts, Spades (suits and associated vals)
        //1    , 2       , 3     , 4

        String cardValPlayer4 = "";
        String suitPlayer4 = "";


        if (cardRand8 == 1) {
            cardValPlayer4 = "Ace"; // 1
        } else if (cardRand8 == 2) {
            cardValPlayer4 = "Two"; // 2
        } else if (cardRand8 == 3) {
            cardValPlayer4 = "Three"; // 3
        } else if (cardRand8 == 4) {
            cardValPlayer4 = "Four"; // 4
        } else if (cardRand8 == 5) {
            cardValPlayer4 = "Five"; // 5
        } else if (cardRand8 == 6) {
            cardValPlayer4 = "Six"; // 6
        } else if (cardRand8 == 7) {
            cardValPlayer4 = "Seven"; // 7
        } else if (cardRand8 == 8) {
            cardValPlayer4 = "Eight"; // 8
        } else if (cardRand8 == 9) {
            cardValPlayer4 = "Nine"; // 9
        } else if (cardRand8 == 10) {
            cardValPlayer4 = "Ten"; // 10
        } else if (cardRand8 == 11) {
            cardValPlayer4 = "Jack"; // 10
			cardRand8 = 10;
        } else if (cardRand8 == 12) {
            cardValPlayer4 = "Queen"; // 10
			cardRand8 = 10;
        } else {
            cardValPlayer4 = "King";  // 10 
			cardRand8 = 10;
        }


        if (suitRand8 == 1) {
            suitPlayer4 = "Clubs"; // 1
        } else if (suitRand8 == 2) {
            suitPlayer4 = "Diamonds"; // 2
        } else if (suitRand8 == 3) {
            suitPlayer4 = "Hearts"; // 3
        } else {
            suitPlayer4 = "Spades"; // 4
        }
		
		
		
		
		
		
		
		
		int dealerTwoCardTotal = cardRand1 + cardRand2;
		int dealerThreeCardTotal = cardRand1 + cardRand2 + cardRand3;
		int dealerFourCardTotal = cardRand1 + cardRand2 + cardRand3 + cardRand4;  // all combos for dealer
		
		
		System.out.println("card1 dealer" + cardRand1);
		System.out.println("card2 dealer" + cardRand2);
		System.out.println("card3 dealer" + cardRand3);
		System.out.println("card4 dealer" + cardRand4);
		
		
		System.out.println(dealerTwoCardTotal);
		System.out.println(dealerThreeCardTotal);
		System.out.println(dealerFourCardTotal);
		
		int dealerFinal = 0; // dealers final count
		
	
		if (dealerTwoCardTotal > 16) {    // picks how many cards dealer hand can have without going over 21
			dealerFinal = dealerTwoCardTotal;
		} else if (dealerThreeCardTotal > 16 && dealerThreeCardTotal < 22) {
			dealerFinal = dealerThreeCardTotal;
		} else if (dealerFourCardTotal > 16 && dealerFourCardTotal < 22) {
			dealerFinal = dealerFourCardTotal;
		} else {
			dealerFinal = dealerFourCardTotal;
		}

		
		System.out.println("dealer final below:");
		System.out.println(dealerFinal);
		System.out.println(" ");
		
		
		int playerTwoCardTotal = cardRand5 + cardRand6;
		int playerThreeCardTotal = cardRand5 + cardRand6 + cardRand7;
		int playerFourCardTotal = cardRand5 + cardRand6 + cardRand7 + cardRand8;  // all combos for player
		
		System.out.println(playerTwoCardTotal);
		System.out.println(playerThreeCardTotal);
		System.out.println(playerFourCardTotal);
		
		int playerFinal = 0;
		
		if (playerTwoCardTotal > 16) {    // picks how many cards dealer hand can have without going over 21
			playerFinal = playerTwoCardTotal;
		} else if (playerThreeCardTotal > 16 && playerThreeCardTotal < 22) {
			playerFinal = playerThreeCardTotal;
		} else if (playerFourCardTotal > 16 && playerFourCardTotal < 22) {
			playerFinal = playerFourCardTotal;
		} else {
			playerFinal = playerFourCardTotal;
		}
		
		System.out.println("player final below:");
		System.out.println(playerFinal);
				
		
   }	
   }
	}
			
   }
	}
	}	
	}
	}
	
	
		
	
//		System.out.println("The Dealer has a face up card of: " + cardValDealer1 + " " + suitDealer1);

		
//		System.out.println("Your two cards are:");
//			}
	}
	}
	
}



	
